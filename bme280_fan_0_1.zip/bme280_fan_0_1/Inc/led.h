#ifndef LED_H_
#define LED_H_

#include "stm32f4xx.h"

#define LED_PORT GPIOE

#define LED1_PIN 0
#define LED2_PIN 1
#define LED3_PIN 2
#define LED4_PIN 3
/*
void LedInit(void);
void LedsOn(void);
void LedsOff(void);
void LedsToggle(void);
*/
#endif

